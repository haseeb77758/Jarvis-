@echo off
setlocal
title Jarvis AI - Windows Startup Setup
cd /d "%~dp0"

echo.
echo ==========================================
echo       JARVIS AI - STARTUP INSTALLER
echo ==========================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not in PATH.
  echo Install Node.js LTS first, then run this file again.
  pause
  exit /b 1
)

if not exist "server.js" (
  echo ERROR: server.js not found.
  pause
  exit /b 1
)

set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "TARGET=%~dp0launch-jarvis.vbs"
set "SHORTCUT=%STARTUP%\Jarvis AI.lnk"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut($env:SHORTCUT); $s.TargetPath='wscript.exe'; $s.Arguments='""' + $env:TARGET + '""'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Description='Jarvis AI Desktop Assistant'; $s.Save()"

echo.
echo SUCCESS: Jarvis AI has been added to Windows Startup.
echo.
echo From now on:
echo   Windows login ^> Desktop ^> Jarvis opens automatically.
echo.
echo To test it now, double-click launch-jarvis.vbs
echo.
pause
