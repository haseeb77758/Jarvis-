Option Explicit
Dim fso, shell, base, nodeCmd, edgeCmd, chromeCmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
base = fso.GetParentFolderName(WScript.ScriptFullName)

' Start the Node server invisibly.
nodeCmd = "cmd /c cd /d """ & base & """ && node server.js"
shell.Run nodeCmd, 0, False

' Give Node a moment to bind to localhost.
WScript.Sleep 2500

' Open Jarvis as a standalone app window.
edgeCmd = "msedge.exe --app=http://localhost:3000"
On Error Resume Next
shell.Run edgeCmd, 1, False
If Err.Number <> 0 Then
  Err.Clear
  chromeCmd = "chrome.exe --app=http://localhost:3000"
  shell.Run chromeCmd, 1, False
End If
On Error GoTo 0
