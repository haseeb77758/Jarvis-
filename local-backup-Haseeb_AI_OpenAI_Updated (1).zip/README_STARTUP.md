# Jarvis AI — Desktop Startup Edition

This version is prepared to start Jarvis automatically after Windows login.

## First setup

1. Make sure Node.js LTS is installed.
2. Make sure your `.env` file contains your API keys.
3. Run `npm install` if dependencies are not already installed.
4. Double-click **INSTALL_STARTUP.bat** once.
5. Test with **launch-jarvis.vbs**.

After that:

**Enter Windows password/PIN → Desktop loads → Jarvis server starts → Jarvis opens in a standalone app window.**

## Important

- The API keys stay in `.env`; do not upload/share that file.
- The startup launcher starts the local Node server invisibly.
- It opens `http://localhost:3000` in Microsoft Edge app mode, with Chrome as fallback.
- `server.js.js` was corrected to `server.js` because `package.json` expects `server.js`.

## Remove automatic startup

Run `REMOVE_STARTUP.bat`.

## Welcome voice

The existing Jarvis project already has ElevenLabs TTS. The desktop startup itself does not expose your API key. The next enhancement can add a dedicated startup greeting such as:

"Welcome Sir. Jarvis is ready."
