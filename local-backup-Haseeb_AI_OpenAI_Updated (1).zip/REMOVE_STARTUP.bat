@echo off
setlocal
set "SHORTCUT=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Jarvis AI.lnk"
if exist "%SHORTCUT%" del /q "%SHORTCUT%"
echo Jarvis AI startup has been removed.
pause
