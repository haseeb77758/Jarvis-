require('dotenv').config();
const express = require('express');
const path = require('path');
const fetch = require('node-fetch');
const { exec } = require('child_process');

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// =========================
// API CONFIGURATION
// =========================
const OPENAI_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';
const SEARCH_KEY = process.env.SEARCHAPI_KEY || '';
const ELEVEN_KEY = process.env.ELEVENLABS_API_KEY || '';
const DEFAULT_VOICE_ID = process.env.ELEVENLABS_VOICE_ID || '21m00Tcm4TlvDq8ikWAM';

// Safe apps that can be opened WITHOUT confirmation.
const APP_WHITELIST = {
  chrome: 'start chrome',
  'google chrome': 'start chrome',
  edge: 'start msedge',
  browser: 'start msedge',
  notepad: 'start notepad',
  calculator: 'start calc',
  calc: 'start calc',
  'file explorer': 'start explorer',
  explorer: 'start explorer',
  files: 'start explorer',
  paint: 'start mspaint',
  wordpad: 'start wordpad',
  settings: 'start ms-settings:',
  cmd: 'start cmd',
  terminal: 'start cmd',
  whatsapp: 'start whatsapp:',
  spotify: 'start spotify:',
  word: 'start winword',
  excel: 'start excel',
  powerpoint: 'start powerpnt',

  // Web apps
  'whatsapp web': 'start https://web.whatsapp.com',
  snapchat: 'start https://web.snapchat.com',
  claude: 'start https://claude.ai',
  gemini: 'start https://gemini.google.com',
  youtube: 'start https://youtube.com',
  facebook: 'start https://facebook.com',
  instagram: 'start https://instagram.com',
  twitter: 'start https://twitter.com',
  x: 'start https://x.com',
  tiktok: 'start https://tiktok.com',
  linkedin: 'start https://linkedin.com',
  gmail: 'start https://mail.google.com',
  email: 'start https://mail.google.com',
  telegram: 'start https://web.telegram.org',
  discord: 'start https://discord.com/app',
  reddit: 'start https://reddit.com',
  pinterest: 'start https://pinterest.com'
};

// =========================
// SEARCH API
// =========================
app.post('/api/search', async (req, res) => {
  try {
    if (!SEARCH_KEY) {
      return res.status(400).json({ error: '.env mein SEARCHAPI_KEY nahi hai' });
    }

    const { query } = req.body || {};
    if (!query) return res.status(400).json({ error: 'query zaroori hai' });

    const url = 'https://www.searchapi.io/api/v1/search?engine=google&q=' +
      encodeURIComponent(query) + '&api_key=' + encodeURIComponent(SEARCH_KEY);

    const r = await fetch(url);
    if (!r.ok) {
      const errorText = await r.text();
      return res.status(r.status).json({
        error: 'Search API error: ' + r.status + ' — ' + errorText.slice(0, 200)
      });
    }

    const data = await r.json();
    const results = (data.organic_results || []).slice(0, 5).map(x => ({
      title: x.title || '',
      link: x.link || '',
      snippet: x.snippet || ''
    }));

    res.json({ results });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// =========================
// OPENAI JARVIS BRAIN
// =========================
app.post('/api/respond', async (req, res) => {
  try {
    if (!OPENAI_KEY) {
      return res.status(400).json({ error: '.env mein OPENAI_API_KEY nahi hai' });
    }

    const { message, history, searchResults } = req.body || {};
    if (!message) return res.status(400).json({ error: 'message zaroori hai' });

    const contextBlock = (searchResults && searchResults.length)
      ? searchResults.map((r, i) =>
          `${i + 1}. ${r.title || ''} — ${r.snippet || ''} (${r.link || ''})`
        ).join('\n')
      : 'Koi search result nahi mila. Zaroorat ho to apni maloomat se jawab dein.';

    const systemInstruction = `
Aap "Jarvis" hain — user ke personal Windows AI assistant.

Language:
- User jis language/style mein baat kare, usi style mein jawab dein.
- Roman Urdu, Urdu aur English ko naturally handle karein.
- Spoken-friendly, natural aur concise jawab dein.

Aapko har message par pehle decide karna hai ke user:
1) normal chat/sawal kar raha hai, YA
2) direct computer/system action command de raha hai.

SYSTEM COMMANDS:
- App kholna: action = "open_app"
- Custom Windows command: action = "run_command"
- Shutdown: action = "shutdown"
- Restart: action = "restart"

Sirf is JSON structure mein jawab dein:

COMMAND:
{
  "is_command": true,
  "action": "open_app|run_command|shutdown|restart",
  "target": "app ka naam ya command",
  "dangerous": true,
  "explanation": "user ko dikhane ke liye chhota Roman Urdu jumla"
}

NORMAL CHAT:
{
  "is_command": false,
  "answer": "spoken-friendly jawab"
}

Rules:
- dangerous=true for shutdown, restart, delete/format operations, or arbitrary/custom shell commands.
- dangerous=false only for opening a known safe app from the whitelist.
- Agar user sirf information pooch raha hai, is_command=false.
- Search results diye gaye hon to unhein relevant jawab mein use karein.
- Search results ko blindly trust na karein; unhein context samjhein.
- JSON ke ilawa koi extra text na dein.
`;

    // Keep the recent conversation small enough for fast responses.
    const recentHistory = (history || []).slice(-8).map(h => ({
      role: h.role === 'assistant' ? 'assistant' : 'user',
      content: String(h.text || '')
    }));

    const userInput =
      `User ka latest message:\n${message}\n\n` +
      `Taza Google search results:\n${contextBlock}`;

    // OpenAI Responses API.
    const responsePayload = {
      model: OPENAI_MODEL,
      instructions: systemInstruction,
      input: [
        ...recentHistory,
        { role: 'user', content: userInput }
      ],
      max_output_tokens: 700
    };

    const r = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + OPENAI_KEY
      },
      body: JSON.stringify(responsePayload)
    });

    if (!r.ok) {
      const errText = await r.text();
      return res.status(r.status).json({
        error: 'OpenAI error: ' + r.status + ' — ' + errText.slice(0, 500)
      });
    }

    const data = await r.json();

    // Responses API normally exposes the final text through output_text.
    let text = data.output_text || '';

    // Fallback parser for response payloads where output_text is not present.
    if (!text && Array.isArray(data.output)) {
      for (const item of data.output) {
        if (!Array.isArray(item.content)) continue;
        for (const part of item.content) {
          if (part.type === 'output_text' && part.text) text += part.text;
        }
      }
    }

    if (!text) {
      return res.status(502).json({ error: 'OpenAI se khaali jawab aaya.' });
    }

    // The model is instructed to return JSON. Remove accidental markdown fences.
    text = text.trim()
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i, '')
      .replace(/\s*```$/i, '')
      .trim();

    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch (e) {
      // Safe fallback: treat malformed model output as normal chat.
      parsed = { is_command: false, answer: text };
    }

    res.json(parsed);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// =========================
// ELEVENLABS TEXT-TO-SPEECH
// =========================
app.post('/api/tts', async (req, res) => {
  try {
    if (!ELEVEN_KEY) {
      return res.status(400).json({ error: '.env mein ELEVENLABS_API_KEY nahi hai' });
    }

    const { text, voiceId } = req.body || {};
    if (!text) return res.status(400).json({ error: 'text zaroori hai' });

    const vid = voiceId || DEFAULT_VOICE_ID;

    const r = await fetch('https://api.elevenlabs.io/v1/text-to-speech/' + encodeURIComponent(vid), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': ELEVEN_KEY,
        'Accept': 'audio/mpeg'
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75
        }
      })
    });

    if (!r.ok) {
      const errText = await r.text();
      return res.status(r.status).json({
        error: 'ElevenLabs error: ' + r.status + ' — ' + errText.slice(0, 300)
      });
    }

    res.set('Content-Type', 'audio/mpeg');
    r.body.pipe(res);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// =========================
// WINDOWS SYSTEM CONTROL
// =========================
app.post('/api/system-execute', (req, res) => {
  const { action, target, confirmed } = req.body || {};
  if (!action) return res.status(400).json({ error: 'action zaroori hai' });

  const key = (target || '').toLowerCase().trim();
  const whitelisted = action === 'open_app' && APP_WHITELIST[key];

  // Only whitelisted safe apps can run without confirmation.
  // Everything else needs an explicit confirmation from the frontend.
  if (!whitelisted && !confirmed) {
    return res.status(403).json({
      error: 'confirmation zaroori hai',
      needsConfirm: true
    });
  }

  let cmd;

  if (action === 'open_app') {
    cmd = whitelisted || null;
    if (!cmd) return res.status(400).json({ error: 'ye app whitelist mein nahi hai' });
  } else if (action === 'shutdown') {
    cmd = 'shutdown /s /t 5';
  } else if (action === 'restart') {
    cmd = 'shutdown /r /t 5';
  } else if (action === 'run_command') {
    cmd = target;
    if (!cmd) return res.status(400).json({ error: 'command khali hai' });
  } else {
    return res.status(400).json({ error: 'na-maloom action' });
  }

  exec(cmd, (err, stdout, stderr) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ ok: true, output: (stdout || stderr || '').slice(0, 500) });
  });
});

// =========================
// CONFIGURATION STATUS
// =========================
app.get('/api/status', (req, res) => {
  res.json({
    openaiReady: !!OPENAI_KEY,
    // Kept for frontend compatibility with the old Jarvis UI.
    geminiReady: false,
    searchReady: !!SEARCH_KEY,
    ttsReady: !!ELEVEN_KEY,
    model: OPENAI_MODEL
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('Jarvis server chal raha hai: http://localhost:' + PORT);
  console.log('OpenAI:', OPENAI_KEY ? 'READY' : 'MISSING');
  console.log('Search API:', SEARCH_KEY ? 'READY' : 'MISSING');
  console.log('ElevenLabs:', ELEVEN_KEY ? 'READY' : 'MISSING');
  console.log('Model:', OPENAI_MODEL);
});
