# Jarvis AI — Backend Server

Ye setup aapki API keys server par (`.env` file mein) mehfooz rakhta hai —
browser mein kabhi nahi jatin. Ek dafa `.env` fill karne ke baad, kisi bhi
browser mein `http://localhost:3000` kholein, seedha kaam karega.

## Setup (pehli baar)

1. **Node.js install karein** (agar nahi hai): https://nodejs.org (LTS version)

2. Is folder mein terminal / PowerShell kholein aur likhein:
   ```
   npm install
   ```

3. `.env.example` file ka naam badal kar `.env` kar dein, aur usmein apni
   4 cheezein daal dein:
   ```
   GEMINI_API_KEY=aapki_gemini_key
   SEARCHAPI_KEY=aapki_searchapi_key
   ELEVENLABS_API_KEY=aapki_elevenlabs_key
   ELEVENLABS_VOICE_ID=21m00Tcm4TlvDq8ikWAM
   ```

4. Server start karein:
   ```
   npm start
   ```

5. Browser mein kholein:
   ```
   http://localhost:3000
   ```

Bas — ab jab bhi server chalega (`npm start`), koi bhi browser is URL par
seedha kaam karega, settings ya keys dobara nahi maangega. Mic permission
bhi ab kaam karega kyunke `localhost` secure context hai.

## Roz istemal ke liye

Har baar sirf ye chalayein:
```
npm start
```
aur `http://localhost:3000` browser mein kholein.

## Zaroori baat

`.env` file kisi ke saath share na karein — is mein aapki asal API keys
hain. Ye file `.gitignore` mein bhi daal dein agar kabhi is code ko GitHub
par upload karein.
