require('dotenv').config();
const express = require('express');
const path = require('path');
const fetch = require('node-fetch');

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const GEMINI_KEY = process.env.GEMINI_API_KEY || '';
const SEARCH_KEY = process.env.SEARCHAPI_KEY || '';
const ELEVEN_KEY = process.env.ELEVENLABS_API_KEY || '';
const DEFAULT_VOICE_ID = process.env.ELEVENLABS_VOICE_ID || '21m00Tcm4TlvDq8ikWAM';

// --- Google search (via SearchAPI.io) ---
app.post('/api/search', async (req, res) => {
  try {
    if (!SEARCH_KEY) return res.status(400).json({ error: '.env mein SEARCHAPI_KEY nahi hai' });
    const { query } = req.body;
    if (!query) return res.status(400).json({ error: 'query zaroori hai' });

    const url = 'https://www.searchapi.io/api/v1/search?engine=google&q=' +
      encodeURIComponent(query) + '&api_key=' + encodeURIComponent(SEARCH_KEY);
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).json({ error: 'Search API error: ' + r.status });
    const data = await r.json();
    const results = (data.organic_results || []).slice(0, 5).map(x => ({
      title: x.title, link: x.link, snippet: x.snippet || ''
    }));
    res.json({ results });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// --- Gemini chat ---
app.post('/api/chat', async (req, res) => {
  try {
    if (!GEMINI_KEY) return res.status(400).json({ error: '.env mein GEMINI_API_KEY nahi hai' });
    const { message, history, searchResults } = req.body;
    if (!message) return res.status(400).json({ error: 'message zaroori hai' });

    const contextBlock = (searchResults && searchResults.length)
      ? searchResults.map((r, i) => (i + 1) + '. ' + r.title + ' — ' + r.snippet + ' (' + r.link + ')').join('\n')
      : 'Koi search result nahi mila, apni maloomat se jawab dein.';

    const systemInstruction = {
      parts: [{
        text: "Aap 'Jarvis' hain, aik garmjosh, dostana aur madadgar AI sathi jo user se usi zaban aur andaz mein baat karta hai jis mein wo baat kar raha hai (Roman Urdu, Urdu script, ya English — jo bhi user use kare). Aapka lehja apna, insaan jaisa, mukhtasar aur pyaar bhara hai, robotic nahi. Neeche diye gaye taza Google search results ko apni maloomat mein shamil kar ke sahi aur updated jawab dein, lekin unko hu-ba-hu na dohrayein — apne alfaz mein samjhayein. Agar search results mautzu (relevant) na hon to apni maloomat se madad karein. Jawab bolne ke qabil (spoken-friendly) rakhein — na zyada lamba, na khushk fehrist jaisa."
      }]
    };

    const contents = [];
    (history || []).slice(-8).forEach(h => {
      contents.push({ role: h.role === 'assistant' ? 'model' : 'user', parts: [{ text: h.text }] });
    });
    contents.push({ role: 'user', parts: [{ text: 'User ka sawal: ' + message + '\n\nTaza Google search results:\n' + contextBlock }] });

    const url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(GEMINI_KEY);
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ system_instruction: systemInstruction, contents })
    });
    if (!r.ok) {
      const errText = await r.text();
      return res.status(r.status).json({ error: 'Gemini error: ' + r.status + ' — ' + errText.slice(0, 200) });
    }
    const data = await r.json();
    const text = data.candidates && data.candidates[0] && data.candidates[0].content
      ? data.candidates[0].content.parts.map(p => p.text || '').join('')
      : '';
    if (!text) return res.status(502).json({ error: 'Gemini se khaali jawab aaya.' });
    res.json({ text });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// --- ElevenLabs text-to-speech ---
app.post('/api/tts', async (req, res) => {
  try {
    if (!ELEVEN_KEY) return res.status(400).json({ error: '.env mein ELEVENLABS_API_KEY nahi hai' });
    const { text, voiceId } = req.body;
    if (!text) return res.status(400).json({ error: 'text zaroori hai' });

    const vid = voiceId || DEFAULT_VOICE_ID;
    const r = await fetch('https://api.elevenlabs.io/v1/text-to-speech/' + vid, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': ELEVEN_KEY
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: { stability: 0.5, similarity_boost: 0.75 }
      })
    });
    if (!r.ok) {
      const errText = await r.text();
      return res.status(r.status).json({ error: 'ElevenLabs error: ' + r.status + ' — ' + errText.slice(0, 200) });
    }
    res.set('Content-Type', 'audio/mpeg');
    r.body.pipe(res);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Tells the frontend which features are actually configured
app.get('/api/status', (req, res) => {
  res.json({
    geminiReady: !!GEMINI_KEY,
    searchReady: !!SEARCH_KEY,
    ttsReady: !!ELEVEN_KEY
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('Jarvis server chal raha hai: http://localhost:' + PORT);
});
