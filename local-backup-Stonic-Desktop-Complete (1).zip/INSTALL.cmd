@echo off
cd /d "%~dp0"
set "STONIC_PY=%LocalAppData%\Python\pythoncore-3.12-64\python.exe"
if not exist "%STONIC_PY%" (
  echo Python 3.12 not found. Install Python 3.12 first.
  pause
  exit /b 1
)
"%STONIC_PY%" -m venv .venv
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install -r requirements.txt selenium opencv-python numpy pyperclip pygetwindow
if errorlevel 1 (
  echo Installation failed. Check the internet connection and errors above.
  pause
  exit /b 1
)
.venv\Scripts\python.exe agent.py download-files
if errorlevel 1 exit /b 1
echo Setup finished. Start microphone voice from the desktop launcher.
pause
