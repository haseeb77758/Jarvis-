"""Windows launcher for the upstream Stonic console voice agent."""
import os
import subprocess
import sys
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
process = None
root = tk.Tk()
root.title('Haseeb | Stonic Desktop')
root.geometry('620x450')
root.configure(bg='#091426')
tk.Label(root, text='STONIC DESKTOP', bg='#091426', fg='#56dfed', font=('Segoe UI', 24, 'bold')).pack(pady=20)
tk.Label(root, text='Local microphone • Google Realtime • Windows tools', bg='#091426', fg='white').pack()
status = tk.StringVar(value='Ready to configure. Voice connection has not been tested.')
tk.Label(root, textvariable=status, wraplength=560, bg='#091426', fg='#f6cf76').pack(pady=15)

def configure():
    env = ROOT / '.env'
    if not env.exists():
        env.write_text('GOOGLE_API_KEY=\nLIVEKIT_URL=\nLIVEKIT_API_KEY=\nLIVEKIT_API_SECRET=\nGOOGLE_SEARCH_API_KEY=\nSEARCH_ENGINE_ID=\nOPENWEATHER_API_KEY=\nGROQ_API_KEY=\n', encoding='utf-8')
    subprocess.Popen(['notepad.exe', str(env)])

def install():
    subprocess.Popen(['cmd.exe', '/k', str(ROOT / 'INSTALL.cmd')], cwd=ROOT)
    status.set('Dependency installation opened. Wait for its result, then start voice.')

def start():
    global process
    if process and process.poll() is None:
        return
    python = ROOT / '.venv' / 'Scripts' / 'python.exe'
    if not python.exists():
        messagebox.showerror('Setup required', 'Run Install dependencies first.')
        return
    probe = subprocess.run([str(python), '-c', 'from dotenv import load_dotenv; import os; load_dotenv(); raise SystemExit(0 if os.getenv("GOOGLE_API_KEY") else 2)'], cwd=ROOT, capture_output=True)
    if probe.returncode:
        messagebox.showerror('Configuration required', 'Set your own GOOGLE_API_KEY in Configure keys. Do not share keys in chat.')
        return
    process = subprocess.Popen([str(python), 'agent.py', 'console'], cwd=ROOT, creationflags=subprocess.CREATE_NEW_CONSOLE)
    status.set('Voice process launched; check its console for microphone/connection result.')

def stop():
    global process
    if process and process.poll() is None:
        process.terminate()
        process.wait(timeout=10)
    process = None
    status.set('Voice stopped.')

def poll():
    if process and process.poll() is not None:
        status.set(f'Voice process exited ({process.returncode}). Read its console/log before retrying.')
    root.after(1000, poll)

for label, command in [('1. Configure keys', configure), ('2. Install dependencies', install), ('3. Start microphone voice', start), ('Disconnect', stop)]:
    tk.Button(root, text=label, command=command, width=32, font=('Segoe UI', 11), pady=5).pack(pady=4)
def close():
    stop()
    root.destroy()
root.protocol('WM_DELETE_WINDOW', close)
poll()
root.mainloop()
