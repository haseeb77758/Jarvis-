# Stonic desktop setup

Source: https://github.com/Nikhil-AI-Labs/Stonic-your-AI-assitant
Snapshot: 93db94c9f82ffebdbd5c0ab63fd646f4dc9b0e51

Run START-STONIC.cmd. Configure your own GOOGLE_API_KEY, install dependencies, then start microphone voice. LiveKit console mode uses local audio; room/deployment mode additionally needs LiveKit credentials. Optional search, weather and Groq tools need their own keys. API access and quotas depend on the provider.

The original web launchers are retained for reference, but are not used: upstream lacks jarvis-ui and imports nonexistent code-fixer functions. The desktop launcher uses agent.py console instead. Added explicit .env loading. No upstream credentials were copied.

This checkout is separate from the existing Jarvis application. No previous Jarvis installation was overwritten. Syntax checks do not establish runtime compatibility. Dependency installation, live audio, model access and Windows tool behavior require verification on the target machine. Desktop tools can type, click, close windows and shut down Windows; start with a simple greeting in an empty workspace.
