@echo off
cd /d "%~dp0"
"%LocalAppData%\Python\pythoncore-3.12-64\python.exe" desktop_launcher.py
if errorlevel 1 pause
